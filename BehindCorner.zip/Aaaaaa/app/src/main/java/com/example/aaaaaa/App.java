package com.example.aaaaaa;

import android.app.Application;
import android.content.Context;
import android.content.res.Resources;

import java.util.ResourceBundle;

public class App extends Application {
    private static Resources resources;

    public static Context context;

    @Override
    public void onCreate() {
        super.onCreate();
        context = getApplicationContext();
        resources = getResources();
    }

    public static Resources getAppResources() {
        return resources;
    }

}
