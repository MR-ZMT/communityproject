package com.example.aaaaaa;

import android.app.Activity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.google.android.gms.maps.model.LatLng;

public class PlaceDescription extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.description_popup); // Set layout referecing description_popup.xml


        // Set the percantage of phone to suit different devices.
        // im gonna test it with every available vd that is avalaible, im not gonna sleep too <3

        double xPercent = 1; double yPercent = .95; // how big window

        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        getWindow().setLayout((int)(dm.widthPixels * xPercent), (int)(dm.heightPixels * yPercent));
        getWindow().setGravity(Gravity.BOTTOM);

        Bundle bundle = getIntent().getExtras();

        String title = getIntent().getStringExtra("title");
        int photo = bundle.getInt("photo");
        String description = getIntent().getStringExtra("description");
        LatLng position = getIntent().getExtras().getParcelable("position");

        setContentView(R.layout.description_popup);
        TextView topTitle = findViewById(R.id.top_title);
        ImageView image = findViewById(R.id.imageView);
        TextView desc = findViewById(R.id.description);
        topTitle.setText(title);
        image.setImageResource(photo);
        desc.setText(description);


    }
}
