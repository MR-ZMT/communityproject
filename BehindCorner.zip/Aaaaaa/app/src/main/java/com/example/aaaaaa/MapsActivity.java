package com.example.aaaaaa;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.example.aaaaaa.databinding.ActivityMapsBinding;

import java.util.ArrayList;
import java.util.Locale;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {



    ArrayList<LatLng> positionList = new ArrayList<>();
    ArrayList<String> nameList = new ArrayList<>();
    ArrayList<Integer> photoList = new ArrayList<>();
    ArrayList<String> descriptionList = new ArrayList<>();




    private GoogleMap mMap;
    private ActivityMapsBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);



        binding = ActivityMapsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);


        positionList.add(new LatLng(52.165585791631166, 21.102052391104912));
        nameList.add(App.getAppResources().getString(R.string.Neogothic_title));
        photoList.add(R.drawable.wilanow);
        descriptionList.add(App.getAppResources().getString(R.string.Neogothic_desc));

        positionList.add(new LatLng(52.16899282740827, 21.09183689456139));
        nameList.add(App.getAppResources().getString(R.string.WilanowskiePond_title));
        photoList.add(R.drawable.wilanow);
        descriptionList.add(App.getAppResources().getString(R.string.WilanowskiePond_desc));

        positionList.add(new LatLng(52.161812073848616, 21.10201652206463));
        nameList.add(App.getAppResources().getString(R.string.GolfPark_title));
        photoList.add(R.drawable.wilanow);
        descriptionList.add(App.getAppResources().getString(R.string.GolfPar_desc));

        positionList.add(new LatLng(52.16583227430902, 21.08987072883619));
        nameList.add(App.getAppResources().getString(R.string.RoyalLightsGarden_title));
        photoList.add(R.drawable.wilanow);
        descriptionList.add(App.getAppResources().getString(R.string.RoyalLightsGarden_desc));

        positionList.add(new LatLng(52.16414003941259, 21.088197742896657));
        nameList.add(App.getAppResources().getString(R.string.PosterMuseum_title));
        photoList.add(R.drawable.wilanow);
        descriptionList.add(App.getAppResources().getString(R.string.PosterMuseum_desc));

        positionList.add(new LatLng(52.1653355599357, 21.090912212207193));
        nameList.add(App.getAppResources().getString(R.string.BaroqueGarden_title));
        photoList.add(R.drawable.wilanow);
        descriptionList.add(App.getAppResources().getString(R.string.BaroqueGarden_desc));

        positionList.add(new LatLng(52.166752482339604, 21.0917412654344));
        nameList.add(App.getAppResources().getString(R.string.WilanowskiWaterTower_title));
        photoList.add(R.drawable.wilanow);
        descriptionList.add(App.getAppResources().getString(R.string.WilanowskiWaterTower_desc));

        positionList.add(new LatLng(52.17171751924182, 21.090908285224543));
        nameList.add(App.getAppResources().getString(R.string.RaszynMonument_title));
        photoList.add(R.drawable.wilanow);
        descriptionList.add(App.getAppResources().getString(R.string.RaszynMonument_desc));

        positionList.add(new LatLng(52.13644928349891, 21.064878154533936));
        nameList.add(App.getAppResources().getString(R.string.PhesantryPark_title));
        photoList.add(R.drawable.botaniczny);
        descriptionList.add(App.getAppResources().getString(R.string.PhesantryPark_desc));

        positionList.add(new LatLng(52.128980053236916, 21.033474701853333));
        nameList.add(App.getAppResources().getString(R.string.BoulderEnigma_title));
        photoList.add(R.drawable.kabacki);
        descriptionList.add(App.getAppResources().getString(R.string.BoulderEnigma_desc));

        positionList.add(new LatLng(52.20969644120345, 21.033774000570304));
        nameList.add(App.getAppResources().getString(R.string.JutrzenkaSculpture_title));
        photoList.add(R.drawable.lazienki);
        descriptionList.add(App.getAppResources().getString(R.string.JutrzenkaSculpture_desc));

        positionList.add(new LatLng(52.21103176288735, 21.033972241044737));
        nameList.add(App.getAppResources().getString(R.string.SolarClock_title));
        photoList.add(R.drawable.lazienki);
        descriptionList.add(App.getAppResources().getString(R.string.SolarClock_desc));

        positionList.add(new LatLng(52.21344124626524, 21.03007927358755));
        nameList.add(App.getAppResources().getString(R.string.BelwederskiPond_title));
        photoList.add(R.drawable.lazienki);
        descriptionList.add(App.getAppResources().getString(R.string.BelwederskiPond_desc));






//        positionList.add(pos_);
//        nameList.add(name_);
//        photoList.add(photo_);
//        descriptionList.add(desc_);


    }



    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(52.2,21), 12));
        for (int i = 0; i < positionList.size(); i++) {
            mMap.addMarker(new MarkerOptions().position(positionList.get(i)).title(nameList.get(i))).setTag(i);
        }

        Intent intent = getIntent();

        Bundle bundle = intent.getExtras();

        if (bundle != null) {

            String title = getIntent().getStringExtra("title");
            int photo = bundle.getInt("photo");
            String description = getIntent().getStringExtra("description");
            LatLng position = getIntent().getExtras().getParcelable("position");

            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(position, 15));

            Intent lead_intent = new Intent(MapsActivity.this, PlaceDescription.class);
            lead_intent.putExtra("title", title);
            lead_intent.putExtra("photo", photo);
            lead_intent.putExtra("description", description);
            lead_intent.putExtra("position_list", position);

            startActivity(lead_intent);
        }

        mMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(@NonNull Marker marker) {
                mMap.moveCamera(CameraUpdateFactory.newLatLng(marker.getPosition()));
                Intent marker_intent = new Intent(MapsActivity.this, PlaceDescription.class);
                marker_intent.putExtra("title", marker.getTitle());
                marker_intent.putExtra("photo", photoList.get((Integer) marker.getTag()));
                marker_intent.putExtra("description", descriptionList.get((Integer) marker.getTag()));
                marker_intent.putExtra("position", marker.getPosition());

                startActivity(marker_intent);
                return false;
            }
        });
    }


    public void onClick(View view) {
        Intent list_intent = new Intent(MapsActivity.this, PlaceList.class);
        list_intent.putExtra("title_list", nameList);
        list_intent.putExtra("photo_list", photoList);
        list_intent.putExtra("description_list", descriptionList);
        list_intent.putExtra("position_list", positionList);
        startActivity(list_intent);
    }

    public void aboutClick(View view) {
        Intent about_page = new Intent(MapsActivity.this, About.class);
        startActivity(about_page);
    }

    public void settingsClick(View view) {

    }
}