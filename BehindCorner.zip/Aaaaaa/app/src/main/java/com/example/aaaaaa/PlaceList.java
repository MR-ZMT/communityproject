package com.example.aaaaaa;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.google.android.gms.maps.model.LatLng;

import java.util.ArrayList;
import java.util.Locale;

public class PlaceList extends AppCompatActivity {

    ListView lv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_place_list);
        lv = (ListView) findViewById(R.id.listview);

        Bundle bundle = getIntent().getExtras();

        ArrayList<String> titleList = getIntent().getStringArrayListExtra("title_list");
        ArrayList<Integer> imageList = getIntent().getIntegerArrayListExtra("photo_list");
        ArrayList<String> descList = getIntent().getStringArrayListExtra("description_list");
        ArrayList<LatLng> positionList = getIntent().getExtras().getParcelableArrayList("position_list");

        ArrayList<String> placeList = new ArrayList<>();


        getSupportActionBar().hide();


        for (int i = 0; i < titleList.size(); i++) {
            placeList.add(titleList.get(i));
        }


        ArrayAdapter arAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, placeList);

        lv.setAdapter(arAdapter);


        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(PlaceList.this, MapsActivity.class);
                intent.putExtra("title", titleList.get(i));
                intent.putExtra("photo", imageList.get(i));
                intent.putExtra("description", descList.get(i));
                intent.putExtra("position", positionList.get(i));
                startActivity(intent);
            }
        });
    }
}
